-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Feb 24, 2018 at 07:56 AM
-- Server version: 10.1.10-MariaDB
-- PHP Version: 7.0.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `online-ticket`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `password`, `name`) VALUES
(1, '123', 'Asif Tanim'),
(2, '12345', 'Tanim Asif'),
(3, '12345', 'test'),
(4, '123', 'test'),
(6, '12345', 'MAHADI HASAN'),
(7, '12345', 'MAHADI HASAN');

-- --------------------------------------------------------

--
-- Table structure for table `booked_seat`
--

CREATE TABLE `booked_seat` (
  `bus_id` int(100) NOT NULL,
  `date` varchar(100) NOT NULL,
  `booked_seats` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `booked_seat`
--

INSERT INTO `booked_seat` (`bus_id`, `date`, `booked_seats`) VALUES
(1, '2017-07-31 21:07:08', '0,37,23,,,,,,,,1,13,34,2'),
(2, '2017-10-19 09:49:58', '0');

-- --------------------------------------------------------

--
-- Table structure for table `bus_info`
--

CREATE TABLE `bus_info` (
  `id` int(100) NOT NULL,
  `bus_name` varchar(100) NOT NULL,
  `bus_des` varchar(100) NOT NULL,
  `bus_type` varchar(100) NOT NULL,
  `dept_time` varchar(100) NOT NULL,
  `arr_time` varchar(100) NOT NULL,
  `fare` int(100) NOT NULL,
  `dept_location` varchar(50) NOT NULL,
  `arr_location` varchar(50) NOT NULL,
  `route` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bus_info`
--

INSERT INTO `bus_info` (`id`, `bus_name`, `bus_des`, `bus_type`, `dept_time`, `arr_time`, `fare`, `dept_location`, `arr_location`, `route`) VALUES
(1, 'Eagle Paribahan', 'AC RM2 Luxurious Chair Coach', 'AC', '7:15 AM', '5:00', 1200, 'Dhaka', 'Khulna', 'Dhaka-Khulna'),
(2, 'Eagle Paribahan', 'Normal Chair Coach', 'NON-AC', '9:00 AM', '6:00 PM', 600, 'Dhaka', 'Chittagong', 'Dhaka-Comilla-Chittagong'),
(3, 'Shohag', 'Ac Chair coac Hundai', 'AC', '11:11', '23:11', 1000, 'Chittagong', 'Dhaka', 'Chittagong-Comilla-Dhaka'),
(9, 'test', 'test des2', 'AC', '10:00', '22:00', 1000, 'Dhaka', 'Khulna', 'dhaka-khulna'),
(10, '', '', '', '', '', 0, '', '', ''),
(11, '', '', '', '', '', 0, '', '', ''),
(14, '', '', '', '', '', 0, '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `transition`
--

CREATE TABLE `transition` (
  `transition_id` int(11) NOT NULL,
  `bus_id` varchar(100) NOT NULL,
  `user_mail` varchar(100) NOT NULL,
  `booked_seats` varchar(200) NOT NULL,
  `user_number` varchar(20) NOT NULL,
  `date` varchar(100) NOT NULL,
  `price` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `transition`
--

INSERT INTO `transition` (`transition_id`, `bus_id`, `user_mail`, `booked_seats`, `user_number`, `date`, `price`) VALUES
(1, '1', 'test@test.com', '12,13', '01623066414', '10-07-2017', '1000'),
(2, '1', 'mahadi@gmail.com', '0,37', '01672667977', '2017-07-30 13:20:14', '2400'),
(3, '1', '', '23', '', '2017-07-30 13:59:02', '1200'),
(4, '', '', '', '', '2017-07-30 22:10:09', ''),
(5, '', '', '', '', '2017-07-30 22:35:00', ''),
(6, '1', '', '', '', '2017-07-30 23:03:53', ''),
(7, '1', 'MAHADI@GMAIL.COM', '', '1234', '2017-07-30 23:15:42', ''),
(8, '1', 'MAHADI@GMAIL.COM', '', '01672667977', '2017-07-30 23:25:20', ''),
(9, '1', 'MAHADI@GMAIL.COM', '', '1234', '2017-07-31 00:14:04', ''),
(10, '1', 'MAHADI@GMAIL.COM', '', '01672667977', '2017-07-31 00:24:39', ''),
(11, '1', 'MAHADI@GMAIL.COM', '', '01672667977', '2017-07-31 00:29:09', ''),
(12, '1', 'MAHADI@GMAIL.COM', '', '01672667977', '2017-07-31 00:45:08', ''),
(13, '1', 'MAHADI@GMAIL.COM', '1', '01672667977', '2017-07-31 01:25:26', '1200'),
(14, '1', 'MAHADI@GMAIL.COM', '13', '01672667977', '2017-07-31 10:27:24', '1200'),
(15, '1', 'MAHADI@GMAIL.COM', '34', '01672667977', '2017-07-31 20:24:29', '1200'),
(16, '1', 'MAHADI@GMAIL.COM', '2', '01672667977', '2017-07-31 21:07:08', '1200'),
(17, '2', 'mahadi@hasan', '0', '01672667977', '2017-10-19 09:49:58', '600');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `booked_seat`
--
ALTER TABLE `booked_seat`
  ADD PRIMARY KEY (`bus_id`);

--
-- Indexes for table `bus_info`
--
ALTER TABLE `bus_info`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `transition`
--
ALTER TABLE `transition`
  ADD PRIMARY KEY (`transition_id`),
  ADD UNIQUE KEY `transition_id` (`transition_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `booked_seat`
--
ALTER TABLE `booked_seat`
  MODIFY `bus_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `bus_info`
--
ALTER TABLE `bus_info`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
--
-- AUTO_INCREMENT for table `transition`
--
ALTER TABLE `transition`
  MODIFY `transition_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
