<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

$config = array(
	'search' => array(
					array(
						'field' => 'from',
						'label' => 'Starting place',
						'rules' => 'required|strtoupper'
						),
					array(
						'field' => 'to',
						'label' => 'Destination',
						'rules' => 'required|strtoupper'
						),
					array(
						'field' => 'jdate',
						'label' => 'journy Date',
						'rules' => 'required|strtoupper'
						)
					),
	'contact' =>array(
					array(
						'field'=>'user_email',
						'label'=>'Email',
						'rules'=>'required|strtoupper'
						),

					array(
						'field'=>'user_number',
						'label'=>'Contact Number',
						'rules'=>'required|strtoupper'
						)

					)

	);