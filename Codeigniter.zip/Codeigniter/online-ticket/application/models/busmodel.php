<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class BusModel extends CI_Model
{

    public function getSeatDetails($bus_id)
    {
        $this->load->database();
        $sql = "SELECT * FROM booked_seat where bus_id=$bus_id";
        $result = $this->db->query($sql);
        return $result->row();
    }

    public function busDetails($bus_id)
    {
        $this->load->database();
        $sql = "SELECT * FROM bus_info where id=$bus_id";
        $result = $this->db->query($sql);
        return $result->row_array();
    }

    public function bookseat($bus)
    {
        $this->load->database();


//updating transition table

        $sql ="INSERT into transition (transition_id,bus_id,user_mail,user_number,date,price,booked_seats)
        VALUES (null,'$bus[id]','$bus[user_email]','$bus[user_number]',NOW(),'$bus[fare]','$bus[bookedSeat]')";

        $this->db->query($sql);

//updating booked_seat table

        $sql1 = "SELECT * FROM booked_seat where bus_id=$bus[id]";
        $result = $this->db->query($sql1);

        if (isset($result->row()->booked_seats)){

        $beforeUpdate= $result->row()->booked_seats;
        $sql2 ="
        UPDATE booked_seat
        SET bus_id='$bus[id]',
        date =NOW(),
        booked_seats = '$beforeUpdate,$bus[bookedSeat]'
        WHERE bus_id = $bus[id]";
        }
        else{
        $sql2 ="INSERT into booked_seat (bus_id,date,booked_seats)
        VALUES ('$bus[id]',NOW(),'$bus[bookedSeat]')";
        }
        $this->db->query($sql2);
}
}
