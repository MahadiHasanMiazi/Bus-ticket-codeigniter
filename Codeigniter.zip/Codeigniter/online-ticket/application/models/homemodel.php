<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Homemodel extends CI_Model
{

    public function getAll($route)
    {
        $this->load->database();
        $testsql="SELECT * FROM bus_info where dept_location like '%$route[from]%' and route like '%$route[to]%'";
        $result = $this->db->query($testsql);
        return $result->result_array();
    }

}