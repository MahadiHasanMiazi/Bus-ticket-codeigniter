/*
 * see COPYRIGHT
 */


/* version number */
#define TTF2PT1_VERSION "3.4.4"
