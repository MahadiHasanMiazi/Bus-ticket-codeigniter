<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Details extends CI_Controller {


    public function busSaetDetails($bus_id)
        {

        $result['book'] = "";

        if(! $this->input->get_post('book'))
        {
            $this->load->model('busmodel');

            $seats=$this->busmodel->getSeatDetails($bus_id);

            $result['id'] =  $bus_id;


            //getting info about booked_seats
            if (isset($seats->booked_seats)){
                $seats=explode(',',$seats->booked_seats);
            }

            //for showing seatinfo in view_details

            $char=64; // this  prints A B C D+......
            $showSeatno=0; // The number besied A,B like A1  B2......
            $result['seatInfo']="";

            for ($seatno=0; $seatno<40; $seatno++){

                $showSeatno++;

                if ($seatno%4==0){
                    $char++;
                    $showSeatno=1;
                    $result['seatInfo'].="<tr></tr>";
                }

                if (in_array($seatno,$seats)){
                    $result['seatInfo'].="<td align='center' bgcolor='red'><input type='checkbox' name='seatno[]' disabled='disabled'>".chr($char).$showSeatno."</td>";
                }
                else{
                    $result['seatInfo'].="<td bgcolor='green'><input type='checkbox' name='seatno[]' value='$seatno'>".chr($char).$showSeatno."</td>";
                }
            }

            $this->load->library('parser');
            $this->parser->parse('view_details', $result);

        }

        else {

            $this->load->model('busmodel');

            $bus['id'] = $this->input->get_post('bus_id');

            $result= $this->busmodel->busDetails($bus['id']);

            $bookedSeatDetails= $this->input->get_post('seatno');

            function seatInfo($seat_no){

                $seat_no+=1;

                $seat_name="";

                $temp=$seat_no%4;
                if($temp==0){
                    $temp=4;
                }


                if($seat_no>=1 && $seat_no<=4){
                    $seat_name.="A".$temp;

                }
                else if($seat_no>=5 && $seat_no<=8){
                    $seat_name.="B".$temp;
                }
                else if($seat_no>=9 && $seat_no<=12){
                    $seat_name.="C".$temp;
                }
                else if($seat_no>=13 && $seat_no<=16){
                    $seat_name.="D".$temp;
                }
                else if($seat_no>=17 && $seat_no<=20){
                    $seat_name.="E".$temp;
                }
                else if($seat_no>=21 && $seat_no<=24){
                    $seat_name.="F".$temp;
                }
                else if($seat_no>=25 && $seat_no<=28){
                    $seat_name.="G".$temp;
                }
                else if($seat_no>=29 && $seat_no<=32){
                    $seat_name.="H".$temp;
                }
                else if($seat_no>=33 && $seat_no<=36){
                    $seat_name.="I".$temp;
                }
                else if($seat_no>=37 ){
                    $temp=$seat_no%5;
                    if($temp==0){
                        $temp=5;
                    }

                    $seat_name.="J".$temp;
                }

                return $seat_name;
            }


            $result['bookedSeatno']="";
            foreach ($bookedSeatDetails as $seat){
                $result['bookedSeatno'].=seatInfo($seat)." ";
            }


            $result['bookedSeatDetails']=implode(",", $bookedSeatDetails);
            $result['totalFare']= $result['fare']*sizeof($bookedSeatDetails);


           $this->load->library('parser');

           $this->parser->parse('view_fare', $result);

        }

    }


    public function bookSeat(){
        
        
        $this->load->model('busmodel');
        $bus['bookedSeat'] = $this->input->get_post('bookedSeats');
        $bus['id'] = $this->input->get_post('bus_id');


        $bus['user_email'] = $this->input->get_post('user_email');
        $bus['user_number'] = $this->input->get_post('user_number');
        $bus['fare'] = $this->input->get_post('fare');


        $this->busmodel->bookSeat($bus);
        $this->pdfGenerate($bus);

    }



    public  function pdfGenerate($bus){

    $this->load->library('parser');

    $result= $this->busmodel->busDetails($bus['id']);

    $bus['dept_location']=$result['dept_location'];
    $bus['arr_location']=$result['arr_location'];
    $bus['dept_time']=$result['dept_time'];
    $bus['route']=$result['route'];


    $bus['bookedSeat']=explode(",",$bus['bookedSeat']);


//        //for showing seatinfo in view_details
//
        $char=64; // this  prints A B C D+......
        $showSeatno=0; // The number besied A,B like A1  B2......
        $bus['seatInfo']="";

        for ($seatno=0; $seatno<40; $seatno++){

            $showSeatno++;

            if ($seatno%4==0){
                $char++;
                $showSeatno=1;
                $bus['seatInfo'].="<tr></tr>";
            }

            if (in_array($seatno, $bus['bookedSeat'])){
                $bus['seatInfo'].="<td width=\"40\" height=\"40\" bgcolor=\"green\" align=\"center\">"."<font color='white'>".chr($char).$showSeatno."</font>"."</td>";
            }
            else{
                $bus['seatInfo'].="<td width=\"40\" height=\"40\" bgcolor=\"red\" align=\"center\">"."<font color='white'>".chr($char).$showSeatno."</font>"."</td>";
            }
        }



//        generatae pdf

        $this->load->view('view_ticket',$bus);
        // Get output html
//        $html = $this->output->get_output();
//
//        // Load library
//        $this->load->library('dompdf_gen');
//
//        // Convert to PDF
//        $this->dompdf->load_html($html);
//        $this->dompdf->render();
//        $this->dompdf->stream("welcome.pdf");
  }

}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */
