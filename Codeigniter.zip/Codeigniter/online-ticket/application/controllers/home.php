<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Home extends CI_Controller {

    public function __construct()
    {
        parent::__construct();
        $this->load->model('homemodel');
        $this->load->library('parser');
    }


    public function index()
    {
        $this->load->library('form_validation');
        $result['message']="";
        $result['from']="";
        $result['to']="";
        $result['date']="";

        if(! $this->input->get_post('search'))
        {
            $result['tablehead']=" ";
            $result['buses'] =array();
            $this->parser->parse('view_home', $result);
        }

        else {

            $result['from']=$this->input->get_post('from');
            $result['to']=$this->input->get_post('to');
            $result['date']=$this->input->get_post('jdate');
            if(!$this->form_validation->run('search')){
                 $result['tablehead']=" ";
                 $result['buses'] =array();
                $result['message']=validation_errors();
                $this->parser->parse('view_home', $result);

                return;

            }

            $bus['from'] = $this->input->get_post('from');
            $bus['to'] = $this->input->get_post('to');
            $bus['date'] = $this->input->get_post('jdate');


            $result['tablehead']="      <tr>
            <th align=\"center\">Bus Name</th>
            <th align=\"center\">Description</th>
            <th align=\"center\">Type</th>
            <th align=\"center\">Departure Time</th>
            <th align=\"center\">Arrival Time</th>
            <th align=\"center\">Fare</th>
            <th align=\"center\">Departure Location</th>
            <th align=\"center\">Arrival Location</th>
            <th align=\"center\">Route</th>
            <th align=\"center\">Details</th>
        </tr>";



            $result['buses'] = $this->homemodel->getAll($bus);
            

            $this->parser->parse('view_home', $result);
            
        }
    }

   
}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */
