<?php

$showSeatno=0;
$char=64;

for ($seatno=0; $seatno<40; $seatno++){

    $showSeatno++;

    if ($seatno%4==0){
        $char++;
        $showSeatno=1;
    }

    $seatdetails[] =chr($char).$showSeatno;
}


foreach($seatdetails as $seat){
    echo $seat;
}