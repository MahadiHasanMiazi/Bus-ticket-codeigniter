<!DOCTYPE html>
<head>
    <title>Page Title</title>
</head>
<body>

                <table border="1" width="500" cellpadding="10" align="center">

                    <tr align="center">
                        <td colspan="2">
                            Bus Name: {bus_name} <br/>
                            Route: {route} <br/>
                            Type: {bus_type} <br/>
                            Deprature Time: {dept_time} <br/>
                            Deprature Location: {dept_location} <br/>
                        </td>
                    </tr>



                	<tr align="center">
                		<td>Seats</td>
                		<td>Fear</td>
                	</tr>
                	<tr align="center">
                		<td height="100">

                          {bookedSeatno}

                        </td>
                		<td height="100">
                            {fare} Per Seat
                        </td>
                	</tr>

                	<tr align="center">
                		<td>Total</td>
                		<td>{totalFare}</td>
                	</tr>
                </table>

                    <form action="http://localhost/online-ticket/details/bookseat">
                        <input type="hidden" value="{bookedSeatDetails}" name="bookedSeats">
                        <input type="hidden" value="{id}" name="bus_id">
                        <input type="hidden" value="{totalFare}" name="fare">

                        <table align="center" cellspacing="20" border="0">
                            <tr>
                                <td>Email</td>
                                <td> <input type="email" name="user_email"></td>
                            </tr>
                            <tr>
                                <td>Phone Number</td>
                                <td> <input type="text"name="user_number"></td>
                            </tr>
                	    <tr>
                            <td colspan="2" align="center" ><input type="submit" name="book" value="Confirm Booking">
                        </tr>
                        </table>
                    </form>
                    <label style="color: red;"></label>


</html>
</body>
