<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Ticket Booking</title>
</head>
<body>
<h1 align="center">Bus Ticket Booking</h1>
<form method="post">
<table cellpadding="20" align="center">
    <tr>
        <th>From</th>

        <td><input type="text" name="from" value="{from}"></td>
    </tr>

    <tr>
        <th>To</th></br>
        <td><input type="text" name="to" value="{to}"></td>
    </tr>

    <tr>
        <th>Journey Date</th></br>
        <td><input type="date" name="jdate" value="{date}"></td>
    </tr>

    <tr>
        <td align="right" colspan="2"><input type="submit" value="Search Bus" name="search"></td>

    </tr>
</table>

    <table border="1" cellpadding="10" align="center">

       {tablehead}

       {buses}
                <tr>
                    <td align="center">{bus_name}</td>
                    <td align="center">{bus_des}</td>
                    <td align="center">{bus_type}</td>
                    <td align="center">{dept_time}</td>
                    <td align="center">{arr_time}</td>
                    <td align="center">{fare}</td>
                    <td align="center">{dept_location}</td>
                    <td align="center">{arr_location}</td>
                    <td>{route}</td>
                    <td align="center"><a href="http://localhost/online-ticket/details/busSaetDetails/{id}">View Seats</a></td>
                </tr>

        {/buses}

    </table>

</form>
<table border="0" align="center">
    <tr>
        <td>
            <label style="color:red;">{message}</label>
        </td>
    </tr>
    

</table>



</body>
</html>


