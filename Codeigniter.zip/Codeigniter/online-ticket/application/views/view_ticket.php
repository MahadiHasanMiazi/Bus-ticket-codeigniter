<!DOCTYPE html>
<head>
    <title>Page Title</title>
</head>
<body>
        <table align="center" cellpadding="5" cellspacing="8" border="1" bgcolor="#ffefd5">
            <tr>
                <td>From</td>
                <td><?php echo $dept_location ?></td>

                <td>Passenger Name</td>
                <td>XYZ</td>
            </tr>
            <tr>
                <td>To</td>
                <td><?php echo $arr_location ?></td>

                <td>Phone</td>
                <td><?php echo $user_number ?></td>
            </tr>
            <tr>
                <td>Time</td>
                <td><?php echo $dept_time ?></td>

                <td>Email</td>
                <td><?php echo $user_email ?></td>
            </tr>
            <tr>
                <td>Seats</td>
                <td><?php echo $route ?></td>

                <td>Transition</td>
                <td>FFBHG241</td>
            </tr>

        </table>


<br/>
<br/>


<table align="center" cellspacing="5" cellpadding="7" border="5">

 <?php echo $seatInfo ?>

</table>


</html>
</body>
