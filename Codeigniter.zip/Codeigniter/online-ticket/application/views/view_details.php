<!DOCTYPE html>
<html>
<head>
	<title>Seat Details</title>
</head>
<body>
<h2 align="center">Select Seat Position(s)</h2>

<table>
<form>

   <table border="0" cellpadding="5" cellspacing="15" align="center">

        {seatInfo}

        <tr><td><input type='hidden' value={id} name='bus_id'></td></tr>
        <tr><td align='center' colspan='4'><input type='submit' name='book' value='Confirm' ></td></tr>


	</table>
</tr>
</form>
</table>
</body>
</html>